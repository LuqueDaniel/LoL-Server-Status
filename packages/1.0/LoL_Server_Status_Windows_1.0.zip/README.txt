LoL Server Status v1.0
===================================================================
LoL Server Status is an application for checking servers status of
League of Legends.

Author: Daniel Luque

Notes
-------------------------------------------------------------------
 - Not remove w9xpopen.exe from app folder.
 - Create direct access for "LoL Server Status.exe"

Llicense
-------------------------------------------------------------------
LoL Server Status licensed under terms of GPLv3
see license in: http://www.gnu.org/licenses/gpl-3.0.html

Source
-------------------------------------------------------------------
Github Repository: https://github.com/LuqueDaniel/LoL-Server-Status
